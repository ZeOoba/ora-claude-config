---
name: ora-resume-0928-attend-reminder
description: 30-minute heads-up that ora-routine-pause-resume-09-28 needs an attended Desktop session at 10:00 AM ET to approve the re-enable calls.
---

Send ONE email to ggoldberg@oxfordra.net only, no cc, via powershell -File C:\Users\Owner\.claude\scheduled-tasks\_shared\send-via-outlook.ps1. Subject: "[ORA] CC fleet resume fires at 10:00 — approval needed". Body: the ora-routine-pause-resume-09-28 task fires in 30 minutes and needs the Desktop app open with someone present to approve each update_scheduled_task permission prompt (the Desktop runner does not auto-approve these unattended, per register-scheduled-task v2.23). If nobody is available, the resume will sit blocked until the app is next opened. Also note the LAMS/Cowork fleet's resume is separate and must be run from a native on-device Cowork session. This is a reminder only — do not touch any scheduled task.